﻿using DevExpress.Xpf.Core;

namespace FileExplorer.View
{
    public partial class ManageExpressionView : DXWindow
    {
        public ManageExpressionView()
        {
            InitializeComponent();
        }
    }
}
