﻿using System.Windows.Controls;

namespace FileExplorer.View
{
    public partial class ZipExtractView : UserControl
    {
        public ZipExtractView()
        {
            InitializeComponent();
        }
    }
}
