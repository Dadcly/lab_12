﻿using System.Windows.Controls;

namespace FileExplorer.View
{
    public partial class MessageView : UserControl
    {
        public MessageView()
        {
            InitializeComponent();
        }
    }
}
