﻿using System.Windows.Controls;

namespace FileExplorer.View
{
    public partial class RenameView : UserControl
    {
        public RenameView()
        {
            InitializeComponent();
        }
    }
}
