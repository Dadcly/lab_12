﻿using System.Windows.Controls;

namespace FileExplorer.View
{
    public partial class ZipArchiveView : UserControl
    {
        public ZipArchiveView()
        {
            InitializeComponent();
        }
    }
}
