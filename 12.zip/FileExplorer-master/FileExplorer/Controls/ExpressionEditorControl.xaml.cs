﻿using DevExpress.Xpf.Editors;

namespace FileExplorer.Controls
{
    public partial class ExpressionEditorControl : ButtonEdit
    {
        public ExpressionEditorControl()
        {
            InitializeComponent();
        }        
    }
}
